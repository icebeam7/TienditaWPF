﻿namespace TienditaWPF.Model
{
    public class ClienteM : ObservableObject
    {
        private int _id;
        public int ID
        {
            get { return _id; }
            set {  if (value != _id) { _id = value; OnPropertyChanged("ID"); } }
        }

        private string _nombre;
        public string Nombre
        {
            get { return _nombre; }
            set { if (value != _nombre) { _nombre = value; OnPropertyChanged("Nombre"); } }
        }

        private string _apellido;
        public string Apellido
        {
            get { return _apellido; }
            set { if (value != _apellido) { _apellido = value; OnPropertyChanged("Apellido"); } }
        }
    }
}
