﻿using System;

namespace TienditaWPF.Model
{
    public class PedidoM : ObservableObject
    {
        private int _id;
        public int ID
        {
            get { return _id; }
            set { if (value != _id) { _id = value; OnPropertyChanged("ID"); } }
        }

        private int _idCliente;
        public int IDCliente
        {
            get { return _idCliente; }
            set { if (value != _idCliente) { _idCliente = value; OnPropertyChanged("IDCliente"); } }
        }

        private DateTime _fecha;
        public DateTime Fecha
        {
            get { return _fecha; }
            set { if (value != _fecha) { _fecha = value; OnPropertyChanged("Fecha"); } }
        }

        private decimal _monto;
        public decimal Monto
        {
            get { return _monto; }
            set { if (value != _monto) { _monto = value; OnPropertyChanged("Monto"); } }
        }

    }
}
