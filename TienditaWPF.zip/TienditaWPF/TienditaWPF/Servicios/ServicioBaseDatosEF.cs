﻿using System.Collections.Generic;
using System.Linq;
using TienditaWPF.Datos;
using TienditaWPF.Model;

namespace TienditaWPF.Servicios
{
    public class ServicioBaseDatosEF
    {
        TienditaEntidades conexion;

        public ServicioBaseDatosEF()
        {
            conexion = new TienditaEntidades();
        }

        public List<ClienteM> ObtenerClientes()
        {
            var tabla = conexion.Cliente.OrderBy(x => x.Apellido);
            var lista = new List<ClienteM>();

            foreach (var item in tabla)
            {
                lista.Add(new ClienteM()
                {
                    ID = item.ID,
                    Nombre = item.Nombre,
                    Apellido = item.Apellido
                });
            }

            return lista;
        }

        private Cliente ObtenerCliente(int id)
        {
            return conexion.Cliente.Where(x => x.ID == id).FirstOrDefault();
        }

        public void AgregarCliente(ClienteM modelo)
        {
            Cliente item = new Cliente()
            {
                ID = modelo.ID,
                Nombre = modelo.Nombre,
                Apellido = modelo.Apellido
            };

            conexion.Cliente.Add(item);
            conexion.SaveChanges();
        }

        public void ActualizarCliente(ClienteM modelo)
        {
            Cliente item = ObtenerCliente(modelo.ID);
            item.ID = modelo.ID;
            modelo.Nombre = modelo.Nombre;
            modelo.Apellido = modelo.Apellido;

            conexion.SaveChanges();
        }

        public void EliminarCliente(ClienteM modelo)
        {
            Cliente item = ObtenerCliente(modelo.ID);
            conexion.Cliente.Remove(item);
            conexion.SaveChanges();
        }

        public List<PedidoM> ObtenerPedidos()
        {
            var tabla = conexion.Pedido;
            var lista = new List<PedidoM>();

            foreach (var item in tabla)
            {
                lista.Add(new PedidoM()
                {
                    ID = item.ID,
                    IDCliente = item.IDCliente,
                    Fecha = item.Fecha,
                    Monto = item.Monto
                });
            }

            return lista;
        }

        private Pedido ObtenerPedido(int id)
        {
            return conexion.Pedido.Where(x => x.ID == id).FirstOrDefault();
        }

        public void AgregarPedido(PedidoM modelo)
        {
            Pedido item = new Pedido()
            {
                ID = modelo.ID,
                IDCliente = modelo.IDCliente,
                Fecha = modelo.Fecha,
                Monto = modelo.Monto
            };

            conexion.Pedido.Add(item);
            conexion.SaveChanges();
        }

        public void ActualizarPedido(PedidoM modelo)
        {
            Pedido item = ObtenerPedido(modelo.ID);
            item.ID = modelo.ID;
            item.IDCliente = modelo.IDCliente;
            item.Fecha = modelo.Fecha;
            item.Monto = modelo.Monto;

            conexion.SaveChanges();
        }

        public void EliminarPedido(PedidoM modelo)
        {
            Pedido item = ObtenerPedido(modelo.ID);
            conexion.Pedido.Remove(item);
            conexion.SaveChanges();
        }

        public List<PedidoM> ObtenerPedidosCliente(ClienteM cliente)
        {
            var tabla = conexion.Pedido.Where(x => x.IDCliente == cliente.ID);
            var lista = new List<PedidoM>();

            foreach (var item in tabla)
            {
                lista.Add(new PedidoM()
                {
                    ID = item.ID,
                    IDCliente = item.IDCliente,
                    Fecha = item.Fecha,
                    Monto = item.Monto
                });
            }

            return lista;
        }
    }
}