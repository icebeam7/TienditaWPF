﻿using System.Collections.Generic;
using TienditaWPF.Model;
using TienditaWPF.Servicios;

namespace TienditaWPF.ViewModel
{
    public class InformacionViewModel : ObservableObject
    {
        private ServicioBaseDatosEF bd;

        private List<ClienteM> _clientes;

        public List<ClienteM> Clientes
        {
            get { return _clientes; }
            set { if (value != _clientes) { _clientes = value; OnPropertyChanged("Clientes"); } }
        }

        private List<PedidoM> _pedidos;

        public List<PedidoM> Pedidos
        {
            get { return _pedidos; }
            set { if (value != _pedidos) { _pedidos = value; OnPropertyChanged("Pedidos"); } }
        }

        public InformacionViewModel()
        {
            bd = new ServicioBaseDatosEF();

            Clientes = bd.ObtenerClientes();
        }

        private ClienteM _clienteSeleccionado;

        public ClienteM ClienteSeleccionado
        {
            get { return _clienteSeleccionado; }
            set
            {
                if (value != _clienteSeleccionado)
                {
                    _clienteSeleccionado = value;
                    OnPropertyChanged("ClienteSeleccionado");
                    ObtenerPedidosCliente();
                }
            }
        }

        private void ObtenerPedidosCliente()
        {
            this.Pedidos = bd.ObtenerPedidosCliente(ClienteSeleccionado);
        }

        private PedidoM _pedidoSeleccionado;

        public PedidoM PedidoSeleccionado
        {
            get { return _pedidoSeleccionado; }
            set
            {
                if (value != _pedidoSeleccionado)
                {
                    _pedidoSeleccionado = value;
                    OnPropertyChanged("PedidoSeleccionado");
                }
            }
        }
    }
}
