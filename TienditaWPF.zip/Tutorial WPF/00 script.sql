create database Tiendita
go
use Tiendita
go

create table Cliente(
  ID int identity(1,1) primary key,
  Nombre varchar(100) not null,
  Apellido varchar(100) not null
)

insert into Cliente values ('Gonzalo', 'Gonzalez')
insert into Cliente values ('Domingo', 'Dominguez')
insert into Cliente values ('Fernando', 'Fernandez')

create table Pedido(
  ID int identity(1,1) primary key,
  IDCliente int foreign key references Cliente(ID) not null,
  Fecha smalldatetime not null,
  Monto decimal(10,2) not null
)

insert into Pedido values (1, '2017-01-01', 100)
insert into Pedido values (1, '2017-05-05', 70)
insert into Pedido values (2, '2017-08-02', 220)
insert into Pedido values (2, '2017-03-04', 3020)
insert into Pedido values (3, '2017-01-08', 2380)